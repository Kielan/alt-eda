SKY130 Research & Design Lab

Open locally
1. Extract this ZIP into a folder.
2. Open index.html in your browser.
3. For consistent browser storage and clipboard behavior, serve the folder:
   python3 -m http.server 8000
   Then open http://localhost:8000

Includes the published dashboard, research digest, lessons, nine experiments,
code snippets, quizzes, prerequisites, browser row model and progress log.

Progress is stored in this browser and origin. Use Export notebook and Import
notebook to move your progress between the hosted Site and a local copy.
This package contains no personal browser progress or test results.

The research snapshot is dated November 17, 2026; it does not auto-update.
Source links and optional Google Fonts require internet access. System fonts
are used when web fonts are unavailable.

The row demo is JavaScript only. This package does not run Verilog, Yosys,
physical verification or timing analysis. Included RTL is a companion example,
not recovered Lesson 13 source. Simulator/synthesis results remain unverified.
The existing v0.6 code-review and verification ZIPs are separate deliverables;
they are referenced but are not bundled here.
