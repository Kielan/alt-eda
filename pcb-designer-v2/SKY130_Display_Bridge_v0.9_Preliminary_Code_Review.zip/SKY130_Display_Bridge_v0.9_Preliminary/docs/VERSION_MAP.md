# Version upgrade map (preliminary release)

All new/modified RTL contains explicit inline version annotations. Search with `grep -Rni '\[v0' rtl`.

| Version | Module/file | Delivered changes | Status |
|---|---|---|---|
| v0.6.1 | `line_buffer.v`, `display_soc_v09_core.v` | Malformed line discard, prevent sticky error bit blocking subsequent valid lines | Implementation supplied; simulation pending |
| v0.6.1 | `i2c_reg_slave_v06.v`, `bridge_control.v` | Inherited from v0.6 unchanged; no verified I²C fix claimed | **Unverified** |
| v0.7 | `dsi_v07_controller.v` | Long-packet SOP/EOP counters, sync packets | Preliminary framing only |
| v0.7 | `dsi_phy_contract_v07.v` | Explicit valid/ready, SOP/EOP, HS request boundary | **Not** a MIPI PHY |
| v0.8 | `async_pixel_fifo_v08.v` | Gray-coded dual-clock FIFO for decoded pixels, backpressure, fill levels | CDC regression pending |
| v0.8 | `line_buffer.v` | Memory remains inferred behavioral RTL | **Not** bound to SRAM macro |
| v0.9 | `dp_link_supervisor_v09.v` | HPD, abstract AUX token, external PHY training-status handshake | **Not** a DP receiver or actual training |
| v0.9 | `display_soc_v09_preliminary.v` | New top connects all these blocks to v0.6 digital video core | Integration tests pending |

Inherited v0.6 files remain for comparison, with the original ZIP under `baseline/v0.6.zip`. `display_soc_v06.v` is retained as an unmodified reference, not the v0.9 top.
