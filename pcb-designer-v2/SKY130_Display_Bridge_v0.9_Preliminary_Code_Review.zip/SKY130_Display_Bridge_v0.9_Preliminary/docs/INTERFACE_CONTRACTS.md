# Interface contracts and hardware boundaries

## Incoming decoded DP pixels (v0.9)
External **qualified receiver** supplies RGB888 (one pixel per accepted sample), `dp_decoded_valid`, SOF, EOL, EOF, and obeys `dp_decoded_ready`. This interface is not electrical DisplayPort. The DP link supervisor operates in `core_clk`, while the decoded data stream is sampled in `dp_clk` through a gray-pointer FIFO.

## Display output (v0.7)
`phy_valid && phy_ready` transfers exactly one byte per cycle of `core_clk`. `phy_sop`, `phy_eop` qualify the first and last bytes of each logical packet **only on accepted transfers**. The upstream packetizer must hold stable byte/data/flags under stalls. `phy_hs_request` is only a hint; it is not an LP/HS electrical timing sequence. MIPI D-PHY, C-PHY and LVDS pads are not provided.

## AUX supervisor (v0.9)
`aux_req_token` is a private 32-bit placeholder message to an external controller. It is **not** a DisplayPort AUX transaction. Actual DP AUX channel encode/decode, DPCD, link training, clock recovery, and multi-lane alignment are missing.

## SRAM and clocks (v0.8)
FIFO RAM and line-buffer RAM are behavioral arrays with technology-dependent inference. Neither is connected to a SKY130 SRAM macro. Reset assertion is asynchronous; in real silicon reset release must be synchronized independently per domain. Need static CDC analysis, reset-domain crossing review and timing constraints before physical design.

## I2C and firmware (v0.6 inherited)
I2C address 0x3C and register map are inherited. The I2C slave is an experimental digital implementation; current tests do not establish full I2C compliance. Boot sequencer is a hardware FSM, **not** CPU firmware. The PWM controls are not KTZ8866 analog circuits.
