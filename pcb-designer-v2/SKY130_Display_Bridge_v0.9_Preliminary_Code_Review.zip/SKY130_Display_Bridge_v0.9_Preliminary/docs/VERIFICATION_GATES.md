# Gates before calling anything verified

1. **v0.6.1 I2C:** 100+ randomized writes/reads, repeated START, clock stretching policy, NACK, timing, reset, arbitrary register pointers and readback scoreboard. Currently NOT complete.
2. **v0.6.1 stream:** malformed line recovery, input stalls and downstream random backpressure; check all frames. New test provided for malformed-line recovery only.
3. **v0.7 DSI:** validate RGB payload bytes and ECC/CRC using independent golden vectors, packet boundaries over stalls, HSS/HSE/blanking/video mode and DCS/LP transitions. Current preliminary controller does NOT implement full transport.
4. **v0.8 CDC:** randomized independent clock ratios, wraparound, simultaneous push/pop, full/empty, metastability-safe synchronizers, reset release. Add memory-macro wrapper and physical views.
5. **v0.9 DP:** compliance test vectors for AUX, DPCD, link training and actual stream decode; actual PHY or licensed IP. Abstract supervisor does not satisfy gate.
6. **Synthesis:** run `scripts/synth_v09_generic.sh`, then `scripts/synth_v09_sky130hd.sh`; inspect all warnings, unmapped cells, and cell area. No measured synthesis numbers are bundled.
7. **Hardware:** I/O pads, clocking, voltage domains, ESD, power sequencing, signal integrity, verification by qualified lab. No physical chip compatibility claims.

No simulation or Yosys results have been fabricated for this release.
