#!/usr/bin/env python3
"""Structural checklist only; not HDL syntax, function, or synthesis verification."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
rtl=root/'rtl'
req=['display_soc_v09_preliminary.v','display_soc_v09_core.v','dsi_v07_controller.v','async_pixel_fifo_v08.v','dp_link_supervisor_v09.v','line_buffer.v','dsi_phy_contract_v07.v']
for name in req:
 p=rtl/name
 assert p.is_file(),f'MISSING {name}'
 s=p.read_text()
 assert '`default_nettype none' in s,name
 assert 'endmodule' in s,name
print('STATIC CHECK PASS: required module files and module terminators present')
print('WARNING: does not compile or simulate RTL')
