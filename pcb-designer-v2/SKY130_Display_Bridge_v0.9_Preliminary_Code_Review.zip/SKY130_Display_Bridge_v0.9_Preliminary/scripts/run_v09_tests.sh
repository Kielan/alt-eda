#!/usr/bin/env bash
# [v0.6.1-v0.9] Reproducible, fail-fast preliminary RTL regression.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v iverilog >/dev/null || { echo 'ERROR: install iverilog'; exit 2; }
mkdir -p build
for spec in 'tb_line_recovery_v061:tb_line_recovery_v061.v' 'tb_async_fifo_v08:tb_async_fifo_v08.v' 'tb_dsi_boundaries_v07:tb_dsi_boundaries_v07.v' 'tb_dp_supervisor_v09:tb_dp_supervisor_v09.v'; do
 name="${spec%%:*}"
 file="${spec#*:}"
 echo "==== $name ===="
 iverilog -g2012 -s "$name" -o "build/$name.vvp" "tb/$file" rtl/*.v
 vvp "build/$name.vvp" | tee "build/$name.log"
done
# [v0.6.1] Retain directed legacy I2C test: not a conformance suite.
echo '==== legacy I2C directed test ===='
iverilog -g2012 -s tb_i2c_v06 -o build/tb_i2c_v06.vvp tb/tb_i2c_v06.v rtl/*.v
vvp build/tb_i2c_v06.vvp | tee build/tb_i2c_v06.log
echo 'All invoked tests completed; see each PASS line, failures stop script.'
