#!/usr/bin/env bash
# [v0.9] Illustrative SKY130HD standard-cell mapping. Not tapeout signoff.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SKY130_LIB:?Set SKY130_LIB to a sky130_fd_sc_hd Liberty path}"
test -f "$SKY130_LIB" || { echo "Liberty not found: $SKY130_LIB"; exit 2; }
command -v yosys >/dev/null || { echo 'Install yosys'; exit 2; }
mkdir -p build
printf 'Liberty: %s
' "$SKY130_LIB" > build/sky130hd_environment.txt
yosys -l build/v09_sky130hd.log -p "read_verilog rtl/*.v; hierarchy -check -top display_soc_v09_preliminary; synth -top display_soc_v09_preliminary -noabc; dfflibmap -liberty $SKY130_LIB; abc -liberty $SKY130_LIB; clean; check; stat -liberty $SKY130_LIB; write_verilog -noattr build/v09_sky130hd_mapped.v"
# NOTE: This script is an exploratory mapping exercise. The modeled pixel
# FIFO and line store may turn into thousands of FFs, NOT SRAM macros.
