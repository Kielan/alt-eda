#!/usr/bin/env bash
# [v0.9] Builds preliminary top. Does not constitute a timing report.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v yosys >/dev/null || { echo 'ERROR: install yosys'; exit 2; }
mkdir -p build
# v0.6 legacy and v0.9 new RTL are both parsed, but the top selects v0.9.
yosys -l build/v09_generic.log -p 'read_verilog rtl/*.v; hierarchy -check -top display_soc_v09_preliminary; proc; opt; memory_collect; stat; synth -top display_soc_v09_preliminary; check; stat; write_verilog -noattr build/v09_generic.v'
