# SKY130 Display Bridge — Preliminary v0.9 Code Review

**NOT a functional drop-in LT7911UXC replacement. NOT an actual DisplayPort/MIPI PHY.** This deliverable is a version-commented experimental Verilog integration package through v0.9 with explicit limits.

## Versioned upgrades
- `[v0.6.1]`: malformed line discard/recovery, sticky line error no longer gates every future line. Existing v0.6 I2C remains **unverified**.
- `[v0.7]`: DSI short/long packet SOP/EOP, byte-level external PHY handshake; no full DSI video scheduler or D-PHY.
- `[v0.8]`: gray-pointer asynchronous FIFO carrying decoded RGB + SOF/EOL/EOF across two clocks; memory remains behavioral RTL.
- `[v0.9]`: external-DP decoder HPD / AUX placeholder token / PHY-status supervision and a new integrated top. **No actual DisplayPort link training or receiver implemented.**

## Entry points
- RTL top: `rtl/display_soc_v09_preliminary.v` (`display_soc_v09_preliminary`)
- Verification: `bash scripts/run_v09_tests.sh`
- Generic synthesis: `bash scripts/synth_v09_generic.sh`
- SKY130HD mapping: `SKY130_LIB=/absolute/path/liberty.lib bash scripts/synth_v09_sky130hd.sh`
- Version map: `docs/VERSION_MAP.md`
- Detailed contracts: `docs/INTERFACE_CONTRACTS.md`
- Acceptance checklist: `docs/VERIFICATION_GATES.md`

## Requirements
Icarus Verilog (`iverilog`, `vvp`) for testbenches; Yosys for synthesis. For SKY130HD mapping, a compatible SKY130 HD `.lib` and Yosys install. **The source was assembled and checked statically but HDL tests and synthesis were not executed in this environment.**

## Folder contents
- `rtl/`: version-annotated RTL plus inherited v0.6 modules
- `tb/`: original v0.6 tests + targeted new tests
- `scripts/`: new v0.9 regression and synthesis scripts
- `baseline/`: original v0.6 code archive
- `docs/`: engineering boundary and version review

## Non-goals
No physical LVDS/DSI/DP pins, link training protocol, D-PHY bit serialization, fully verified I2C, SRAM macro signoff, CPU firmware, or KTZ8866 analog rail implementation.
