`default_nettype none
// [v0.9 UPGRADE] DisplayPort receiver SUPERVISOR for an EXTERNAL DP PHY/
// link decoder. HPD input, AUX request tokens and PHY training status only.
// Not a DP receiver: no 8b/10b, 128b/132b, clock recovery, lane alignment,
// DPCD address decode, EDID, TPS1-4, HDCP, DSC or real link negotiation.
// Interface contract: aux_req_valid handshakes one 32-bit controller token;
// external bridge supplies aux_rsp_valid and a PHY link trained indicator.
module dp_link_supervisor_v09(
 input wire clk,rst_n,input wire hpd,
 input wire phy_clock_locked,input wire phy_trained,
 output wire aux_req_valid,output wire [31:0] aux_req_token,
 input wire aux_req_ready,input wire aux_rsp_valid,input wire [7:0] aux_rsp_status,
 output reg link_up,output reg [2:0] state,output reg fault
);
 localparam DOWN=0,WAIT_PHY=1,AUX_REQ=2,AUX_WAIT=3,TRAIN=4,ACTIVE=5;
 reg [15:0] timeout_count;
 // [v0.9 FIX] Request VALID must be asserted in the cycle READY is sampled.
 assign aux_req_valid=(state==AUX_REQ);
 assign aux_req_token=32'hA0910001;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   link_up<=0;state<=DOWN;
   fault<=0;timeout_count<=0;
  end else begin
   if(!hpd)begin
    state<=DOWN;link_up<=0;timeout_count<=0;
   end else case(state)
    DOWN:begin fault<=0;state<=WAIT_PHY;end
    WAIT_PHY:if(phy_clock_locked)begin state<=AUX_REQ;timeout_count<=0;end
    AUX_REQ:begin
     // Abstract request token, NOT a wire-level DisplayPort AUX transaction.
     if(aux_req_ready)state<=AUX_WAIT;
    end
    AUX_WAIT:begin
     if(aux_rsp_valid)begin
      if(aux_rsp_status==0)state<=TRAIN;
      else begin fault<=1;state<=DOWN;end
      timeout_count<=0;
     end else if(timeout_count==16'hffff)begin fault<=1;state<=DOWN;end
     else timeout_count<=timeout_count+1'b1;
    end
    TRAIN:begin
     // An external qualified PHY/link layer must perform actual training.
     if(phy_trained)begin link_up<=1;state<=ACTIVE;end
    end
    ACTIVE:if(!phy_clock_locked || !phy_trained)begin link_up<=0;state<=WAIT_PHY;end
    default:state<=DOWN;
   endcase
  end
 end
endmodule
`default_nettype wire
