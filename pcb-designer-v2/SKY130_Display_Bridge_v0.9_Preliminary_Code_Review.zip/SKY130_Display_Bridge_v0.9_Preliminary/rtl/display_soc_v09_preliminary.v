`default_nettype none
// [v0.9 PRELIMINARY] Version-annotated integration top.
// [v0.6.1] Repaired malformed-line recovery and long-packet status gating.
// [v0.7] Explicit SOP/EOP DSI PHY byte contract; NOT a physical D-PHY.
// [v0.8] Clock-domain crossing for externally DECODED DP pixel samples.
// [v0.9] ABSTRACT AUX/link supervisor driven by external DP decoder status.
// DO NOT connect digital IO directly to DP/MIPI differential lanes.
module display_soc_v09_preliminary #(
 parameter FIFO_AW=4,parameter LINE_DEPTH=4096,parameter LINE_AW=12
)(
 input wire dp_clk,core_clk,rst_n,
 input wire dp_hpd,dp_phy_locked,dp_phy_trained,
 output wire aux_req_valid,output wire [31:0] aux_req_token,
 input wire aux_req_ready,aux_rsp_valid,input wire [7:0] aux_rsp_status,
 output wire dp_link_up,dp_link_fault,
 input wire [23:0] dp_decoded_rgb,
 input wire dp_decoded_valid,dp_decoded_sof,dp_decoded_eol,dp_decoded_eof,
 output wire dp_decoded_ready,
 input wire i2c_scl,i2c_sda_in,output wire i2c_sda_drive_low,
 output wire [7:0] phy_data,output wire phy_valid,
 output wire phy_sop,phy_eop,phy_hs_request,input wire phy_ready,
 output wire panel_enable,backlight_enable,backlight_pwm,
 output wire [2:0] boot_state,output wire buffer_error,dsi_busy,frame_done,
 input wire debug_wr,input wire [7:0] debug_wr_addr,debug_wr_data,
 input wire [7:0] debug_reg_addr,output wire [7:0] debug_reg_data,
 output wire [FIFO_AW:0] fifo_write_level,fifo_read_level
);
 wire [2:0] dp_state;
 dp_link_supervisor_v09 dp_control(.clk(core_clk),.rst_n(rst_n),.hpd(dp_hpd),
  .phy_clock_locked(dp_phy_locked),.phy_trained(dp_phy_trained),
  .aux_req_valid(aux_req_valid),.aux_req_token(aux_req_token),
  .aux_req_ready(aux_req_ready),.aux_rsp_valid(aux_rsp_valid),
  .aux_rsp_status(aux_rsp_status),.link_up(dp_link_up),
  .state(dp_state),.fault(dp_link_fault));
 // [v0.8 CDC] Synchronize stable link enable into DP clock domain.
 (* async_reg = "true" *) reg [1:0] link_dp_sync;
 always @(posedge dp_clk or negedge rst_n)
  if(!rst_n)link_dp_sync<=0;
  else link_dp_sync<={link_dp_sync[0],dp_link_up};
 wire [26:0] pixel_in={dp_decoded_sof,dp_decoded_eol,dp_decoded_eof,dp_decoded_rgb};
 wire [26:0] pixel_out;
 wire pixel_out_valid,pixel_out_ready,raw_input_ready;
 assign dp_decoded_ready=link_dp_sync[1] && raw_input_ready;
 async_pixel_fifo_v08 #(.AW(FIFO_AW)) input_cdc(
  .wr_clk(dp_clk),.rd_clk(core_clk),.rst_n(rst_n),
  .s_data(pixel_in),.s_valid(dp_decoded_valid && link_dp_sync[1]),
  .s_ready(raw_input_ready),.m_data(pixel_out),
  .m_valid(pixel_out_valid),.m_ready(pixel_out_ready),
  .wr_level(fifo_write_level),.rd_level(fifo_read_level));
 wire [7:0] byte_i;
 wire valid_i,sop_i,eop_i,hs_i,ready_i;
 display_soc_v09_core #(.LINE_DEPTH(LINE_DEPTH),.LINE_AW(LINE_AW)) core(
  .clk(core_clk),.rst_n(rst_n),.i2c_scl(i2c_scl),.i2c_sda_in(i2c_sda_in),
  .i2c_sda_drive_low(i2c_sda_drive_low),
  .dp_rgb(pixel_out[23:0]),.dp_valid(pixel_out_valid),
  .dp_sof(pixel_out[26]),.dp_eol(pixel_out[25]),.dp_eof(pixel_out[24]),
  .dp_ready(pixel_out_ready),.phy_byte(byte_i),.phy_valid(valid_i),
  .phy_ready(ready_i),.phy_sop(sop_i),.phy_eop(eop_i),
  .phy_hs_request(hs_i),.panel_enable(panel_enable),
  .backlight_enable(backlight_enable),.backlight_pwm(backlight_pwm),
  .boot_state(boot_state),.debug_reg_data(debug_reg_data),
  .debug_reg_addr(debug_reg_addr),.debug_wr(debug_wr),
  .debug_wr_addr(debug_wr_addr),.debug_wr_data(debug_wr_data),
  .buffer_error(buffer_error),.dsi_busy(dsi_busy),.frame_done(frame_done));
 dsi_phy_contract_v07 phy_adapter(.clk(core_clk),.rst_n(rst_n),
  .s_data(byte_i),.s_valid(valid_i),.s_sop(sop_i),.s_eop(eop_i),
  .s_hs_request(hs_i),.s_ready(ready_i),.phy_data(phy_data),
  .phy_valid(phy_valid),.phy_sop(phy_sop),.phy_eop(phy_eop),
  .phy_hs_request(phy_hs_request),.phy_ready(phy_ready));
endmodule
`default_nettype wire
