`default_nettype none
// [v0.7 UPGRADE] Packet-level SOP/EOP for BOTH short and RGB888 long packets.
// [v0.7 LIMIT] Simplified one-RGB888-packet-per-line video schedule. Not a
// complete DSI video-mode scheduler: HSS/HSE, blanking and LP/HS arbitration
// remain unsupported, and virtual channel is fixed to zero.
module dsi_v07_controller(
 input wire clk,rst_n, input wire line_ready,line_sof,line_eof,
 input wire [15:0] line_length, output reg drain_line,output reg pkt_start,
 input wire [7:0] pkt_data,input wire pkt_valid,input wire pkt_busy,input wire pkt_done,
 output wire [7:0] tx_data,output wire tx_valid,input wire tx_ready,
 output wire tx_sop,tx_eop,output reg [2:0] state,output reg frame_done
);
 localparam IDLE=0,VS=1,START=2,LONG=3,VE=4;
 reg [1:0] short_idx;
 reg [7:0] short_id;
 reg ending;
 reg [15:0] long_index,long_total;
 wire [7:0] short_ecc;
 dsi_header_ecc ecc(.d({16'h0000,short_id}),.ecc(short_ecc));
 wire short_active=(state==VS || state==VE);
 assign tx_valid=short_active ? 1'b1 : (state==LONG ? pkt_valid : 1'b0);
 assign tx_data=short_active ? (short_idx==0?short_id:(short_idx==3?short_ecc:8'h00)) : pkt_data;
 // [v0.7 UPGRADE] SOP/EOP denote accepted bytes only; packet order is
 // one short VS (at frame start), long RGB888, one short VE (at frame end).
 assign tx_sop=tx_valid && (short_active ? short_idx==0 : ((state==LONG)&&(long_index==0)));
 assign tx_eop=tx_valid && (short_active ? short_idx==3 : ((state==LONG)&&(long_index==long_total-1'b1)));
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=IDLE;short_idx<=0;short_id<=0;ending<=0;
   drain_line<=0;pkt_start<=0;frame_done<=0;
   long_index<=0;long_total<=0;
  end else begin
   drain_line<=0;pkt_start<=0;frame_done<=0;
   case(state)
    IDLE:if(line_ready) begin
     ending<=line_eof;
     long_total<=line_length*16'd3+16'd6;
     long_index<=0;
     if(line_sof) begin state<=VS;short_id<=8'h01;short_idx<=0;end
     else state<=START;
    end
    VS:if(tx_ready) begin
     if(short_idx==3)begin short_idx<=0;state<=START;end
     else short_idx<=short_idx+1'b1;
    end
    START:begin drain_line<=1;pkt_start<=1;state<=LONG;end
    LONG:begin
     if(tx_valid && tx_ready) long_index<=long_index+1'b1;
     if(pkt_done)begin
      if(ending)begin state<=VE;short_id<=8'h11;short_idx<=0;end
      else state<=IDLE;
     end
    end
    VE:if(tx_ready) begin
     if(short_idx==3)begin state<=IDLE;short_idx<=0;frame_done<=1;end
     else short_idx<=short_idx+1'b1;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
