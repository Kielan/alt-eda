`default_nettype none
// [v0.7 UPGRADE] Concrete byte-stream handoff to an EXTERNAL DSI host PHY.
// Backpressure may be applied through phy_ready; data/SOP/EOP are held stable
// while valid&&!ready. hs_request is advisory, not a D-PHY HS entry sequence.
// [v0.7 LIMIT] LP-11/LPDT/BTA, escape-mode packets and lane deskew require
// a separately qualified PHY adapter and clock/control domain specification.
module dsi_phy_contract_v07(
 input wire clk,rst_n,input wire [7:0] s_data,input wire s_valid,
 input wire s_sop,s_eop,input wire s_hs_request,output wire s_ready,
 output wire [7:0] phy_data,output wire phy_valid,
 output wire phy_sop,phy_eop,phy_hs_request,input wire phy_ready
);
 // Pure combinational ready/valid adapter. All signals in same clock domain.
 assign s_ready=phy_ready;
 assign phy_data=s_data;assign phy_valid=s_valid;
 assign phy_sop=s_sop;assign phy_eop=s_eop;
 assign phy_hs_request=s_hs_request;
endmodule
`default_nettype wire
