`default_nettype none
// [v0.6.1 UPGRADE] Whole-line ready/valid buffer with deterministic
// malformed-line discard. Sticky errors report anomalies without deadlocking.
// [v0.8 LIMIT] This is a synchronous, single-clock behavioral memory. Mapping
// to a physical SRAM macro requires a separately qualified wrapper.
module line_buffer #(parameter DEPTH=4096, parameter AW=12)(
 input wire clk,rst_n,input wire [15:0] expected_width,
 input wire [23:0] s_rgb,input wire s_valid,s_sof,s_eol,s_eof,
 output wire s_ready,output wire [23:0] m_rgb,output wire m_valid,
 input wire m_ready,input wire begin_drain,
 output reg line_ready,output reg line_sof,output reg line_eof,
 output reg [15:0] line_length,output reg error_length,output reg error_overflow
);
 reg [23:0] mem [0:DEPTH-1];
 reg [AW-1:0] wrptr,rdptr;
 reg [15:0] written,remaining;
 reg draining;
 reg discard;
 wire push=s_valid && s_ready;
 wire pop=m_valid && m_ready;
 assign s_ready=!line_ready && !draining && !discard && (written<DEPTH);
 assign m_valid=draining && (remaining!=0);
 assign m_rgb=mem[rdptr];
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n)begin
   wrptr<=0;rdptr<=0;written<=0;remaining<=0;draining<=0;
   line_ready<=0;line_sof<=0;line_eof<=0;line_length<=0;
   error_length<=0;error_overflow<=0;discard<=0;
  end else begin
   if(discard)begin
    // [v0.6.1 FIX] Release a malformed line for the NEXT accepted line.
    wrptr<=0;written<=0;line_ready<=0;line_sof<=0;
    line_eof<=0;line_length<=0;discard<=0;
   end else if(push)begin
    mem[wrptr]<=s_rgb;
    wrptr<=wrptr+1'b1;
    written<=written+1'b1;
    if(written==0)line_sof<=s_sof;
    if(s_eol)begin
     line_eof<=s_eof;
     line_length<=written+1'b1;
     if((written+1'b1)!=expected_width || expected_width==0)begin
      error_length<=1;discard<=1;
     end else line_ready<=1;
    end else if(written+1'b1>=DEPTH)begin
     // Full without EOL: a producer that obeys ready/valid can otherwise
     // hold valid forever. Sticky error and reset local line state.
     error_overflow<=1;discard<=1;
    end
   end
   if(begin_drain && line_ready && !draining)begin
    draining<=1;rdptr<=0;remaining<=line_length;
   end
   if(pop)begin
    rdptr<=rdptr+1'b1;remaining<=remaining-1'b1;
    if(remaining==1)begin
     draining<=0;line_ready<=0;written<=0;wrptr<=0;
     line_sof<=0;line_eof<=0;
    end
   end
  end
 end
endmodule
`default_nettype wire
