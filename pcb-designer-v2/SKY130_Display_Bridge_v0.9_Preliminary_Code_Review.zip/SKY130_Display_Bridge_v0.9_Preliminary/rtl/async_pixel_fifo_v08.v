`default_nettype none
// [v0.8 UPGRADE] Dual-clock ready/valid FIFO for a decoded pixel stream.
// Gray pointer synchronization; depth must be power of 2 (>=4), AW>=2.
// Data payload packs {sof,eol,eof,rgb} into 27 bits.
// [v0.8 LIMIT] Model uses async memory read; technology-specific SRAM
// macro must be integrated separately. CDC constraints and reset release
// synchronizers are required in the real implementation.
module async_pixel_fifo_v08 #(parameter AW=4)(
 input wire wr_clk,rd_clk,rst_n,
 input wire [26:0] s_data,input wire s_valid,output wire s_ready,
 output wire [26:0] m_data,output wire m_valid,input wire m_ready,
 output wire [AW:0] wr_level,rd_level
);
 localparam DEPTH=(1<<AW);
 reg [26:0] mem [0:DEPTH-1];
 reg [AW:0] wbin,wgray,rbin,rgray;
 (* async_reg = "true" *) reg [AW:0] rgray_w1,rgray_w2;
 (* async_reg = "true" *) reg [AW:0] wgray_r1,wgray_r2;
 wire wfire=s_valid && s_ready;
 wire rfire=m_valid && m_ready;
 wire [AW:0] wbin_next=wbin+wfire;
 wire [AW:0] rbin_next=rbin+rfire;
 wire [AW:0] wgray_next=(wbin_next>>1)^wbin_next;
 wire [AW:0] rgray_next=(rbin_next>>1)^rbin_next;
 // Standard asynchronous FIFO full detection uses inversion of top 2 bits.
 wire full_next=(wgray_next=={~rgray_w2[AW:AW-1],rgray_w2[AW-2:0]});
 wire empty=(rgray==wgray_r2);
 reg full;
 assign s_ready=!full;
 assign m_valid=!empty;
 assign m_data=mem[rbin[AW-1:0]];
 function [AW:0] gray_to_bin;
 input [AW:0] g;
 integer j;
 begin
  gray_to_bin[AW]=g[AW];
  for(j=AW-1;j>=0;j=j-1)gray_to_bin[j]=gray_to_bin[j+1]^g[j];
 end
 endfunction
 assign wr_level=wbin-gray_to_bin(rgray_w2);
 assign rd_level=gray_to_bin(wgray_r2)-rbin;
 always @(posedge wr_clk or negedge rst_n)begin
  if(!rst_n)begin wbin<=0;wgray<=0;rgray_w1<=0;rgray_w2<=0;full<=0;end
  else begin
   rgray_w1<=rgray;rgray_w2<=rgray_w1;
   if(wfire)mem[wbin[AW-1:0]]<=s_data;
   wbin<=wbin_next;wgray<=wgray_next;full<=full_next;
  end
 end
 always @(posedge rd_clk or negedge rst_n)begin
  if(!rst_n)begin rbin<=0;rgray<=0;wgray_r1<=0;wgray_r2<=0;end
  else begin
   wgray_r1<=wgray;wgray_r2<=wgray_r1;
   rbin<=rbin_next;rgray<=rgray_next;
  end
 end
endmodule
`default_nettype wire
