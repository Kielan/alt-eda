`timescale 1ns/1ps
// [v0.9 TEST] External decoder supervision, NOT DisplayPort link training.
module tb_dp_supervisor_v09;
 reg clk=0,rst_n=0,hpd=0,locked=0,trained=0;
 always #5 clk=~clk;
 wire aux_valid,link_up,fault;wire [31:0] token;wire [2:0] state;
 reg rsp_valid=0;
 dp_link_supervisor_v09 dut(.clk(clk),.rst_n(rst_n),.hpd(hpd),
  .phy_clock_locked(locked),.phy_trained(trained),
  .aux_req_valid(aux_valid),.aux_req_token(token),.aux_req_ready(1'b1),
  .aux_rsp_valid(rsp_valid),.aux_rsp_status(8'h00),
  .link_up(link_up),.state(state),.fault(fault));
 initial begin
  #22 rst_n=1;hpd=1;locked=1;
  wait(state==3);@(negedge clk);rsp_valid=1;
  @(negedge clk);rsp_valid=0;trained=1;
  wait(link_up);@(negedge clk);hpd=0;
  repeat(3)@(negedge clk);
  if(link_up)$fatal(1,"HPD loss did not reset link");
  $display("PASS v0.9 abstract link supervisor");$finish;
 end
 initial begin #5000;$fatal(1,"DP supervisor TIMEOUT");end
endmodule
