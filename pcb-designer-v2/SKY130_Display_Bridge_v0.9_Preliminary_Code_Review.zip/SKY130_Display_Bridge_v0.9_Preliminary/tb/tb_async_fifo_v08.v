`timescale 1ns/1ps
// [v0.8 TEST] Independent clocks; deterministic ready/valid stalls.
module tb_async_fifo_v08;
 reg wc=0,rc=0,rst_n=0;
 always #7 wc=~wc;always #11 rc=~rc;
 reg [26:0] data=0;reg valid=0,ready=0;
 wire s_ready,m_valid;wire [26:0] m_data;
 wire [4:0] wl,rl;
 integer next_in=0,next_out=0,cycles=0;
 async_pixel_fifo_v08 #(.AW(4)) dut(.wr_clk(wc),.rd_clk(rc),.rst_n(rst_n),
  .s_data(data),.s_valid(valid),.s_ready(s_ready),
  .m_data(m_data),.m_valid(m_valid),.m_ready(ready),
  .wr_level(wl),.rd_level(rl));
 initial begin
  #50 rst_n=1;
  wait(next_out==100);
  $display("PASS v0.8 FIFO 100 words, dual clocks");$finish;
 end
 always @(negedge wc)if(rst_n)begin
  valid=(next_in<100) && (next_in%7!=5);
  data=next_in;
 end
 always @(posedge wc)if(rst_n && valid && s_ready)next_in=next_in+1;
 always @(negedge rc)if(rst_n)ready=((cycles%11)<7);
 always @(posedge rc)if(rst_n)begin
  cycles=cycles+1;
  if(m_valid && ready)begin
   if(m_data!==next_out) $fatal(1,"FIFO mismatch got=%0d expected=%0d",m_data,next_out);
   next_out=next_out+1;
  end
  if(cycles>3000)$fatal(1,"FIFO TIMEOUT");
 end
endmodule
