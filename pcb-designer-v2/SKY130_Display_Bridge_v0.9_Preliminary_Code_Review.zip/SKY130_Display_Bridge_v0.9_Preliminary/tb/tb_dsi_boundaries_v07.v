`timescale 1ns/1ps
// [v0.7 TEST] Checks packet lengths + SOP/EOP through randomized stalls.
module tb_dsi_boundaries_v07;
 reg clk=0,rst_n=0;
 always #5 clk=~clk;
 reg line_ready=0,line_sof=1,line_eof=1;
 wire drain,start,frame_done,phy_valid,phy_sop,phy_eop;
 wire [7:0] phy_data;
 reg phy_ready=0;
 wire [2:0] state;
 wire [7:0] pkt_data;wire pkt_valid,pkt_busy,pkt_done;
 wire pixel_ready;reg [23:0] pixel_rgb=24'h112233;
 reg pixel_valid=1;
 wire underrun;
 integer n=0,packet=0,idx=0,stalls=0,cycles=0;
 dsi_rgb888_packetizer gen(.clk(clk),.rst_n(rst_n),.start_line(start),
  .line_pixels(16'd2),.pixel_rgb(pixel_rgb),.pixel_valid(pixel_valid),
  .pixel_ready(pixel_ready),.byte_data(pkt_data),.byte_valid(pkt_valid),
  .byte_ready(phy_ready && state==3),.busy(pkt_busy),
  .line_done(pkt_done),.underrun_error(underrun));
 dsi_v07_controller dut(.clk(clk),.rst_n(rst_n),.line_ready(line_ready),
  .line_sof(line_sof),.line_eof(line_eof),.line_length(16'd2),
  .drain_line(drain),.pkt_start(start),.pkt_data(pkt_data),
  .pkt_valid(pkt_valid),.pkt_busy(pkt_busy),.pkt_done(pkt_done),
  .tx_data(phy_data),.tx_valid(phy_valid),.tx_ready(phy_ready),
  .tx_sop(phy_sop),.tx_eop(phy_eop),.state(state),
  .frame_done(frame_done));
 initial begin #31 rst_n=1;@(negedge clk);line_ready=1;
  @(negedge clk);line_ready=0;
 end
 always @(negedge clk)if(rst_n)begin
  phy_ready=((cycles%7)!=3)&&((cycles%7)!=4);
  if(pixel_ready && pixel_valid)begin
   if(n==0)pixel_rgb=24'h112233;
   else pixel_rgb=24'h445566;
  end
 end
 always @(posedge clk)if(rst_n)begin
  cycles=cycles+1;
  if(phy_valid && !phy_ready)stalls=stalls+1;
  if(pixel_ready && pixel_valid)n=n+1;
  if(phy_valid && phy_ready)begin
   if(idx==0 && !phy_sop)$fatal(1,"missing SOP packet %0d",packet);
   if(idx!=0 && phy_sop)$fatal(1,"extra SOP packet %0d",packet);
   if(phy_eop !== (idx==((packet==1)?11:3)))$fatal(1,"bad EOP p=%0d i=%0d",packet,idx);
   if(idx==((packet==1)?11:3))begin idx=0;packet=packet+1;end
   else idx=idx+1;
  end
  if(frame_done)begin
   if(packet!=3)$fatal(1,"expected 3 packets got %0d",packet);
   if(stalls==0)$fatal(1,"did not exercise PHY stalls");
   $display("PASS v0.7 DSI framing, packets=%0d stalls=%0d",packet,stalls);$finish;
  end
  if(cycles>1000)$fatal(1,"DSI boundary TIMEOUT");
 end
endmodule
