`timescale 1ns/1ps
// [v0.6.1 TEST] Malformed one-pixel line (expected 2) must recover.
module tb_line_recovery_v061;
 reg clk=0,rst_n=0,s_valid=0,s_sof=0,s_eol=0,s_eof=0;
 always #5 clk=~clk;
 reg [23:0] s_rgb=0;wire s_ready;
 wire [23:0] m_rgb;wire m_valid,line_ready,line_sof,line_eof;
 wire [15:0] line_length;wire err_len,err_ovf;
 reg m_ready=0,begin_drain=0;
 line_buffer #(.DEPTH(8),.AW(3)) dut(.clk(clk),.rst_n(rst_n),
  .expected_width(16'd2),.s_rgb(s_rgb),.s_valid(s_valid),
  .s_sof(s_sof),.s_eol(s_eol),.s_eof(s_eof),.s_ready(s_ready),
  .m_rgb(m_rgb),.m_valid(m_valid),.m_ready(m_ready),
  .begin_drain(begin_drain),.line_ready(line_ready),
  .line_sof(line_sof),.line_eof(line_eof),.line_length(line_length),
  .error_length(err_len),.error_overflow(err_ovf));
 task pixel(input [23:0] rgb,input endline);
 begin @(negedge clk);s_rgb=rgb;s_eol=endline;s_valid=1;
  if(!s_ready)$fatal(1,"unexpected not ready");
  @(negedge clk);s_valid=0;s_eol=0;
 end endtask
 initial begin
  #23 rst_n=1;
  pixel(24'h111111,1);repeat(3)@(negedge clk);
  if(!err_len || line_ready || !s_ready)$fatal(1,"bad recovery");
  pixel(24'h222222,0);pixel(24'h333333,1);
  if(!line_ready || line_length!=2)$fatal(1,"valid line lost");
  @(negedge clk);begin_drain=1;
  @(negedge clk);begin_drain=0;m_ready=1;
  wait(!line_ready);repeat(2)@(negedge clk);
  if(!s_ready)$fatal(1,"line storage did not reset");
  $display("PASS v0.6.1 malformed line recovery");$finish;
 end
 initial begin #3000;$fatal(1,"line recovery TIMEOUT");end
endmodule
