# v0.6 code-review plan and checklist

## Scope achieved in source

1. **DSI digital controller**: VS_START + RGB888 long packet + VS_END framing, inherited header ECC and CRC-16 byte generation; pixel count and end-of-frame flags. This is **not** complete MIPI DSI video mode or an electrical PHY.
2. **Video buffering**: one full scanline (configurable RAM depth) under ready/valid backpressure; SOP and EOF annotations; reject mismatched line width; release line after draining. Designed for one synchronous clock, **not** a DP-to-PHY CDC.
3. **I2C**: revised oversampled 7-bit slave with register address pointer, sequential byte writes, repeated START for read, open-drain output, explicit ACK / NACK states. A directed testbench is provided. Test results are not claimed unless run.
4. **External PHY contract**: `(phy_byte, phy_valid, phy_ready, phy_sop, phy_eop, phy_hs_request)` at the SAME clock, plus frame_done. SOP/EOP mark the short sync packets; RGB long packet starts at byte `0x3E` but the existing packetizer does not emit its own SOP/EOP. Not a complete/production PHY protocol.

## Review priority / known issues

- Full DSI video mode requires horizontal sync packets, blanking transport, timings, low-power/high-speed switch control, line timing and VC handling, packet scheduling and an appropriate D-PHY/C-PHY core. The present interface is a **byte-stream protocol boundary only**.
- DP input is predecoded RGB; DisplayPort PHY, training, AUX, DSC, framing, clock recovery are absent.
- 1-clock video pipeline latency; EOF is separately delayed. No CDC. A real SoC requires asynchronous FIFO / CDC verification and reset-domain handling.
- The line store deliberately accepts only one whole line. `dp_ready` must be honored; any source that cannot stall needs a separate frame buffer or overflow handling.
- `LINE_DEPTH` must be a power of two, `LINE_AW=clog2(LINE_DEPTH)` and `active_width<=LINE_DEPTH`. Width is programmed at 0x03/0x04, default is 2560. An invalid line sets a sticky fault and blocks packetization until reset. No dynamic reconfiguration mid-frame.
- RAM size is ~4096 × 24 bits by default; **likely impractical in HD standard-cell flip-flops**. Target SRAM macro / wrapper and run memory mapping, floorplanning and timing. Open-source SKY130 SRAM macro availability and licensing must be checked separately.
- I2C is oversampled (no clock stretching, arbitration, or analog glitch filtering). Repeated start / master NACK scenarios need broader coverage and timing verification. This is not a formally verified I2C IP.
- Backlight is PWM and enable only; no KTZ8866 register compatibility, I2C analog driver, LED boost/bias, thermal or power fault design. Real hardware must use qualified LED driver circuitry.
- Firmware currently means configuration registers and a fixed boot sequencer, not programmable CPU/ROM code.
- Physical electrical compatibility with LT7911UXC or Lenovo Legion Go is NOT established.

## Accept / reject criteria for later measured verification

* Compile all RTL with `iverilog -g2012 -Wall` and run tests without fatal/assertion failure.
* Check directed 2-pixel frame byte ordering and 20-byte count.
* I2C write, repeated-START read, slave address NACK, multi-byte sequential read/write tests.
* Randomized stalls at PHY and at RGB input; verify no byte duplication/drop and stable bytes when stalled.
* Recover from reset during packetization; behavior should be specified and tested.
* Generate Yosys mapped stats against a **specific SKY130 Liberty** and report mapped area and unsupported cell/macro count.
* Replace line buffer with SRAM macro (or test small DEPTH), add CDC and pass static timing before claiming ASIC-ready.

## Register map (inherited v0.5)

`0x00` CTRL bit0 video enable, bit1 invert, bit2 test pattern; `0x01` brightness; `0x02` panel/backlight enable; `0x03..04` active_width LE; `0x05` status; `0x06..09` frame and line counters; `0x0A` hold boot; `0x0B` sticky fault W1C; `0x0C` revision **0x06**; `0x0D` ID 0xD5. Test interfaces are intentionally separate from production register writes.
