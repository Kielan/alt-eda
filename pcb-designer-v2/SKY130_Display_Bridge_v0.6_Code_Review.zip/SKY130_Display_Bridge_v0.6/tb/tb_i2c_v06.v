`timescale 1ns/1ps
module tb_i2c_v06;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,scl=1,master_low=0;
 wire slave_low;wire sda=!(master_low || slave_low);
 wire [7:0] addr;reg [7:0] data=8'hA5;
 wire wr;wire [7:0] wa,wd;
 i2c_reg_slave_v06 dut(.clk(clk),.rst_n(rst_n),.scl(scl),
 .sda_in(sda),.sda_drive_low(slave_low),.rd_data(data),
 .rd_addr(addr),.wr_pulse(wr),.wr_addr(wa),.wr_data(wd));
 reg [7:0] captured=0;reg wrote=0;
 always @(posedge clk)if(wr)begin captured<=wd;wrote<=1;end
 task phase(input clkval,input low);begin
  scl=clkval;master_low=low;#250;end endtask
 task start;begin phase(1,0);phase(1,1);phase(0,1);end endtask
 task stop;begin phase(0,1);phase(1,1);phase(1,0);end endtask
 task bitout(input b);begin phase(0,!b);phase(1,!b);phase(0,!b);end endtask
 task byteout(input [7:0] value);integer i;begin
  for(i=7;i>=0;i=i-1)bitout(value[i]);
  phase(0,0);phase(1,0);
  if(sda!==0)$fatal(1,"missing ACK for %h",value);
  phase(0,0);
 end endtask
 task bytein(output [7:0] value);integer i;begin
  master_low=0;
  for(i=7;i>=0;i=i-1)begin
   phase(0,0);phase(1,0);value[i]=sda;phase(0,0);
  end
  bitout(1); // master NACK
 end endtask
 reg [7:0] got;
 initial begin
  #45;rst_n=1;
  start;byteout(8'h78);byteout(8'h01);byteout(8'h5a);stop;
  #100;if(!wrote || captured!==8'h5a)$fatal(1,"I2C write failed");
  start;byteout(8'h78);byteout(8'h01);
  start;byteout(8'h79);bytein(got);stop;
  if(got!==8'hA5)$fatal(1,"I2C repeated-start read failed: %h",got);
  $display("PASS: I2C pointer write, data write, repeated-start read");$finish;
 end
endmodule
