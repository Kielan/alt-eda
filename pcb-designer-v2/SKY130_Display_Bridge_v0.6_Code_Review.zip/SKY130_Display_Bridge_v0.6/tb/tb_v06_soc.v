`timescale 1ns/1ps
module tb_v06_soc;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,scl=1,sda=1;
 reg [23:0] rgb=0;reg valid=0,sof=0,eol=0,eof=0;
 wire ready;wire [7:0] phy_byte;wire phy_valid,phy_sop,phy_eop,phy_hs;
 reg phy_ready=1;
 reg debug_wr=0;reg [7:0] debug_wr_addr=0,debug_wr_data=0;
 wire [7:0] debug_reg_data;reg [7:0] debug_reg_addr=0;
 wire panel,bl,pwm,buffer_error,busy,frame_done,sda_low;
 wire [2:0] boot;
 display_soc_v06 #(.LINE_DEPTH(16),.LINE_AW(4)) dut(
 .clk(clk),.rst_n(rst_n),.i2c_scl(scl),.i2c_sda_in(sda),.i2c_sda_drive_low(sda_low),
 .dp_rgb(rgb),.dp_valid(valid),.dp_sof(sof),.dp_eol(eol),.dp_eof(eof),.dp_ready(ready),
 .phy_byte(phy_byte),.phy_valid(phy_valid),.phy_ready(phy_ready),
 .phy_sop(phy_sop),.phy_eop(phy_eop),.phy_hs_request(phy_hs),
 .panel_enable(panel),.backlight_enable(bl),.backlight_pwm(pwm),.boot_state(boot),
 .debug_reg_data(debug_reg_data),.debug_reg_addr(debug_reg_addr),
 .debug_wr(debug_wr),.debug_wr_addr(debug_wr_addr),.debug_wr_data(debug_wr_data),
 .buffer_error(buffer_error),.dsi_busy(busy),.frame_done(frame_done));
 task wr(input [7:0] a,input [7:0] d);begin
 @(negedge clk);debug_wr_addr=a;debug_wr_data=d;debug_wr=1;
 @(negedge clk);debug_wr=0;end endtask
 task px(input [23:0] color,input fs,input le,input fe);begin
 @(negedge clk);
 while(!ready)@(negedge clk);
 rgb=color;valid=1;sof=fs;eol=le;eof=fe;
 @(negedge clk);valid=0;sof=0;eol=0;eof=0;
 end endtask
 integer seen=0,timeout=0;reg [7:0] bytes[0:63];
 always @(posedge clk)if(rst_n && phy_valid && phy_ready)begin
  bytes[seen]=phy_byte;seen=seen+1;
 end
 initial begin
  #28;rst_n=1;
  wr(8'h03,8'd2);wr(8'h04,8'd0);wr(8'h00,8'h01);
  px(24'h123456,1,0,0);
  px(24'habcdef,0,1,1);
  while(!frame_done && timeout<500)begin @(negedge clk);timeout=timeout+1;end
  if(timeout==500)$fatal(1,"timeout waiting for frame");
  // VS_START (4) + long header(4) + 2*3 pixel data + CRC(2) + VS_END(4) =20
  if(seen!=20)$fatal(1,"byte count expected 20 got %0d",seen);
  if(bytes[0]!==8'h01 || bytes[4]!==8'h3e || bytes[5]!==8'h06 ||
     bytes[6]!==8'h00 || bytes[8]!==8'h12 || bytes[9]!==8'h34 ||
     bytes[10]!==8'h56 || bytes[11]!==8'hab || bytes[12]!==8'hcd ||
     bytes[13]!==8'hef || bytes[16]!==8'h11)
    $fatal(1,"incorrect DSI frame bytes");
  if(buffer_error)$fatal(1,"line buffer reported error");
  $display("PASS: 2-pixel frame, byte framing, line buffering");$finish;
 end
endmodule
