# SKY130 Display Bridge v0.6 — code review release

**Status: review candidate, not physically interoperable hardware.** Built from exact previous v0.5 source archive included under `previous_v05/`.

## Blocks
- `rtl/display_soc_v06.v`: integrated top, predecoded RGB input, register control, output byte PHY interface.
- `rtl/line_buffer.v`: one complete scanline store with ready/valid backpressure.
- `rtl/dsi_v06_controller.v`: short VSYNC packets around inherited RGB888 long packetizer.
- `rtl/i2c_reg_slave_v06.v`: revised 7-bit I2C register slave, address `0x3C`.
- Inherited `video_pipeline`, `dsi_rgb888_packetizer`, ECC/CRC, boot control, backlight PWM, monitor and reader.
- `tb/`: directed RTL tests; `scripts/`: simulation and synthesis commands.
- `docs/PLAN_AND_REVIEW.md`: limitations, full code-review checklist and known blockers.

## Requirements
* Icarus Verilog: `bash scripts/run_tests.sh`
* Yosys: `mkdir -p build && yosys -s scripts/synth_generic.ys`
* SKY130HD Liberty: `SKY130_LIB=/absolute/path/to/sky130_fd_sc_hd__tt_025C_1v80.lib bash scripts/synth_sky130.sh`

## Scope boundaries
This does not include a real DisplayPort PHY/decoder, MIPI D-PHY/C-PHY, physical LVDS pins, KTZ8866-compatible mixed-signal power/LED driver, firmware CPU, nor CDC. It is a digital simulation/synthesis prototype with an external byte-transport contract. `phy_sop` and `phy_eop` currently delimit VSYNC short packets only; framing of long packets needs extension. **Do not fabricate or connect to a Legion Go screen based on this RTL.**

## Verification statement
This package contains testbenches and automated scripts; execution results depend on running them. Release documentation does not substitute tests, STA, PDK signoff or silicon measurements.
