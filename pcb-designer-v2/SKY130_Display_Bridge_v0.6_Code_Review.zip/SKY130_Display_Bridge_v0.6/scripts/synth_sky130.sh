#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SKY130_LIB:?Export SKY130_LIB=/path/to/sky130_fd_sc_hd__tt_025C_1v80.lib}"
mkdir -p build
yosys -p "read_verilog rtl/*.v; hierarchy -check -top display_soc_v06; synth -top display_soc_v06; dfflibmap -liberty $SKY130_LIB; abc -liberty $SKY130_LIB; clean; stat -liberty $SKY130_LIB; write_verilog -noattr build/display_soc_v06_sky130.v"
