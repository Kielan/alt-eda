#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
command -v iverilog >/dev/null || { echo 'ERROR: install iverilog'; exit 127; }
iverilog -g2012 -Wall -s tb_v06_soc -o build/soc.vvp rtl/*.v tb/tb_v06_soc.v
vvp build/soc.vvp
iverilog -g2012 -Wall -s tb_i2c_v06 -o build/i2c.vvp rtl/i2c_reg_slave_v06.v tb/tb_i2c_v06.v
vvp build/i2c.vvp
