`default_nettype none
module bridge_register_reader(input wire [7:0] addr,input wire video_enable,
 input wire invert,test_pattern,input wire [7:0] brightness,
 input wire panel_request,backlight_request,input wire [15:0] active_width,
 input wire [2:0] boot_state,input wire stream_healthy,packet_busy,sticky_fault,hold_boot,
 input wire [15:0] frame_count,line_count,output reg [7:0] data);
 always @* case(addr)
  8'h00:data={5'b0,test_pattern,invert,video_enable};
  8'h01:data=brightness;
  8'h02:data={6'b0,backlight_request,panel_request};
  8'h03:data=active_width[7:0];
  8'h04:data=active_width[15:8];
  8'h05:data={1'b0,packet_busy,sticky_fault,stream_healthy,1'b0,boot_state};
  8'h06:data=frame_count[7:0];
  8'h07:data=frame_count[15:8];
  8'h08:data=line_count[7:0];
  8'h09:data=line_count[15:8];
  8'h0A:data={7'b0,hold_boot};
  8'h0B:data={7'b0,sticky_fault};
  8'h0C:data=8'h06;
  8'h0D:data=8'hD5;
  default:data=8'h00;
 endcase
endmodule
`default_nettype wire
