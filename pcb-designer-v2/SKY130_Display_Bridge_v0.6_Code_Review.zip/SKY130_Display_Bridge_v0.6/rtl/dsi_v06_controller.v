`default_nettype none
// DSI digital byte-stream framing: VSYNC_START (0x01), RGB888 long packet
// (0x3E), VSYNC_END (0x11). VC=0. Short packets carry 0 payload bytes.
// This is NOT a complete DSI video-mode timing controller: no HSS/HSE,
// blanking, escape/LP sequences, PHY turnaround, lane mapping or clock sync.
module dsi_v06_controller(input wire clk,rst_n,
 input wire line_ready,line_sof,line_eof,input wire [15:0] line_length,
 output reg drain_line,output reg pkt_start,
 input wire [7:0] pkt_data,input wire pkt_valid,input wire pkt_busy,input wire pkt_done,
 output wire [7:0] tx_data,output wire tx_valid,input wire tx_ready,
 output wire tx_sop,tx_eop,output reg [2:0] state,output reg frame_done);
 localparam IDLE=0,VS=1,START=2,LONG=3,VE=4;
 reg [1:0] short_idx;
 reg [7:0] short_id;
 wire [7:0] short_ecc;
 wire [23:0] short_hdr={16'h0000,short_id};
 dsi_header_ecc se(.d(short_hdr),.ecc(short_ecc));
 wire short_active=(state==VS || state==VE);
 assign tx_valid=short_active ? 1'b1 : ((state==LONG)?pkt_valid:1'b0);
 assign tx_data=short_active ? (short_idx==0?short_id:(short_idx==3?short_ecc:8'h00)) : pkt_data;
 assign tx_sop=tx_valid && (short_active?short_idx==0:1'b0);
 assign tx_eop=tx_valid && (short_active?short_idx==3:1'b0);
 reg ending;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin state<=IDLE;short_idx<=0;short_id<=0;
   drain_line<=0;pkt_start<=0;frame_done<=0;ending<=0;end
  else begin
   drain_line<=0;pkt_start<=0;frame_done<=0;
   case(state)
    IDLE:if(line_ready) begin
     ending<=line_eof;
     if(line_sof) begin state<=VS;short_id<=8'h01;short_idx<=0;end
     else state<=START;
    end
    VS:if(tx_ready) begin
     if(short_idx==3)begin short_idx<=0;state<=START;end
     else short_idx<=short_idx+1'b1;
    end
    START:begin drain_line<=1;pkt_start<=1;state<=LONG;end
    LONG:if(pkt_done)begin
     if(ending)begin state<=VE;short_id<=8'h11;short_idx<=0;end
     else state<=IDLE;
    end
    VE:if(tx_ready) begin
     if(short_idx==3)begin state<=IDLE;short_idx<=0;frame_done<=1;end
     else short_idx<=short_idx+1'b1;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
