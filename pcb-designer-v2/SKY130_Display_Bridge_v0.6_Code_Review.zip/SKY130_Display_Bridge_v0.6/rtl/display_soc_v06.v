`default_nettype none
// Digital reference. All pixel and byte interfaces use SAME clock.
// External PHY is byte-ready handshake, NOT MIPI D-PHY pins.
// Decoded DP RGB is assumed; no DisplayPort decoding implemented.
module display_soc_v06 #(parameter LINE_DEPTH=4096,parameter LINE_AW=12)(
 input wire clk,rst_n,
 input wire i2c_scl,i2c_sda_in,output wire i2c_sda_drive_low,
 input wire [23:0] dp_rgb,input wire dp_valid,dp_sof,dp_eol,dp_eof,
 output wire dp_ready,
 output wire [7:0] phy_byte,output wire phy_valid,input wire phy_ready,
 output wire phy_sop,phy_eop,output wire phy_hs_request,
 output wire panel_enable,backlight_enable,backlight_pwm,
 output wire [2:0] boot_state,
 output wire [7:0] debug_reg_data,input wire [7:0] debug_reg_addr,
 input wire debug_wr,input wire [7:0] debug_wr_addr,debug_wr_data,
 output wire buffer_error,output wire dsi_busy,output wire frame_done);
 wire iwr;wire [7:0] iwa,iwd,ira,ird;
 i2c_reg_slave_v06 ic(.clk(clk),.rst_n(rst_n),.scl(i2c_scl),.sda_in(i2c_sda_in),
  .sda_drive_low(i2c_sda_drive_low),.rd_data(ird),.rd_addr(ira),
  .wr_pulse(iwr),.wr_addr(iwa),.wr_data(iwd));
 wire we=debug_wr|iwr;
 wire [7:0] wa=debug_wr?debug_wr_addr:iwa;
 wire [7:0] wd=debug_wr?debug_wr_data:iwd;
 wire enable,invert,test_pattern,panel_request,backlight_request,hold_boot;
 wire [7:0] brightness;wire [15:0] active_width;
 wire fault,permit;
 wire [15:0] frame_count,line_count,pixel_count;
 wire stream_healthy;
 wire [23:0] pixel_rgb;wire pixel_valid,pixel_sof,pixel_eol;
 wire error_eol;
 wire input_fire=dp_valid && dp_ready;
 // Video pipeline has one register of latency, so accepted flags are delayed.
 // Input can be throttled by the downstream line store; no input while disabled.
 reg pending_eol;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)pending_eol<=0;
  else pending_eol<=input_fire && dp_eol;
 assign dp_ready=enable && store_ready && !pending_eol && !pixel_eol;
 video_pipeline vp(.clk(clk),.rst_n(rst_n),.s_rgb(dp_rgb),
  .s_valid(input_fire),.s_sof(dp_sof),.s_eol(dp_eol),
  .enable(enable),.invert(invert),.test_pattern(test_pattern),
  .m_rgb(pixel_rgb),.m_valid(pixel_valid),.m_sof(pixel_sof),.m_eol(pixel_eol),
  .frame_count(frame_count),.line_count(line_count),.pixel_count(pixel_count),
  .error_eol_without_pixels(error_eol));
 // EOF is pipelined to match the registered pixel pipeline.
 reg pipe_eof;
 always @(posedge clk or negedge rst_n)if(!rst_n)pipe_eof<=0;
  else pipe_eof<=input_fire && dp_eof;
 wire store_ready,line_ready,line_sof,line_eof;
 wire [15:0] line_length;
 wire err_len,err_overflow;
 wire [23:0] fifo_rgb;wire fifo_valid,fifo_pop,drain_line;
 line_buffer #(.DEPTH(LINE_DEPTH),.AW(LINE_AW)) lb(
  .clk(clk),.rst_n(rst_n),.expected_width(active_width),
  .s_rgb(pixel_rgb),.s_valid(pixel_valid),.s_sof(pixel_sof),
  .s_eol(pixel_eol),.s_eof(pipe_eof),.s_ready(store_ready),
  .m_rgb(fifo_rgb),.m_valid(fifo_valid),.m_ready(fifo_pop),
  .begin_drain(drain_line),.line_ready(line_ready),
  .line_sof(line_sof),.line_eof(line_eof),.line_length(line_length),
  .error_length(err_len),.error_overflow(err_overflow));
 assign buffer_error=err_len|err_overflow|error_eol;
 // Prevent a new pixel from being accepted during the pending registered
 // output cycle once EOL was accepted (avoids a one-entry skid requirement).
 // Producer must obey ready/valid; EOL prohibits further input until line drain.
 wire pstart,pready,pvalid,pbusy,pdone,underrun;
 wire [7:0] pbyte;
 dsi_rgb888_packetizer pkt(.clk(clk),.rst_n(rst_n),
  .start_line(pstart),.line_pixels(line_length),.pixel_rgb(fifo_rgb),
  .pixel_valid(fifo_valid),.pixel_ready(pready),
  .byte_data(pbyte),.byte_valid(pvalid),.byte_ready(phy_ready && dsi_state==3),
  .busy(pbusy),.line_done(pdone),.underrun_error(underrun));
 assign fifo_pop=pready && fifo_valid;
 wire [2:0] dsi_state;
 dsi_v06_controller dsi(.clk(clk),.rst_n(rst_n),
  .line_ready(line_ready && !err_len),.line_sof(line_sof),.line_eof(line_eof),
  .line_length(line_length),.drain_line(drain_line),.pkt_start(pstart),
  .pkt_data(pbyte),.pkt_valid(pvalid),.pkt_busy(pbusy),.pkt_done(pdone),
  .tx_data(phy_byte),.tx_valid(phy_valid),.tx_ready(phy_ready),
  .tx_sop(phy_sop),.tx_eop(phy_eop),.state(dsi_state),.frame_done(frame_done));
 assign dsi_busy=(dsi_state!=0);
 assign phy_hs_request=dsi_busy;
 stream_monitor sm(.clk(clk),.rst_n(rst_n),.video_enable(enable),
  .frame_pulse(pixel_valid && pixel_sof),.stream_healthy(stream_healthy));
 bridge_control bc(.clk(clk),.rst_n(rst_n),.wr_en(we),.addr(wa),.wr_data(wd),
  .rd_data(),.frame_count(frame_count),.line_count(line_count),
  .stream_healthy(stream_healthy),.packet_busy(dsi_busy),
  .clear_fault_external(1'b0),.video_enable(enable),.invert(invert),
  .test_pattern(test_pattern),.brightness(brightness),.active_width(active_width),
  .panel_request(panel_request),.backlight_request(backlight_request),
  .hold_boot(hold_boot),.sticky_stream_fault(fault),
  .boot_state(boot_state),.panel_enable(panel_enable),.backlight_permit(permit));
 bridge_register_reader rr1(.addr(ira),.video_enable(enable),.invert(invert),
  .test_pattern(test_pattern),.brightness(brightness),
  .panel_request(panel_request),.backlight_request(backlight_request),
  .active_width(active_width),.boot_state(boot_state),.stream_healthy(stream_healthy),
  .packet_busy(dsi_busy),.sticky_fault(fault),.hold_boot(hold_boot),
  .frame_count(frame_count),.line_count(line_count),.data(ird));
 bridge_register_reader rr2(.addr(debug_reg_addr),.video_enable(enable),.invert(invert),
  .test_pattern(test_pattern),.brightness(brightness),
  .panel_request(panel_request),.backlight_request(backlight_request),
  .active_width(active_width),.boot_state(boot_state),.stream_healthy(stream_healthy),
  .packet_busy(dsi_busy),.sticky_fault(fault),.hold_boot(hold_boot),
  .frame_count(frame_count),.line_count(line_count),.data(debug_reg_data));
 wire [7:0] pwm_phase;
 ktz8866_control_proxy bl(.clk(clk),.rst_n(rst_n),.permit(permit),
  .brightness(brightness),.led_enable(backlight_enable),
  .led_pwm(backlight_pwm),.pwm_phase(pwm_phase));
endmodule
`default_nettype wire
