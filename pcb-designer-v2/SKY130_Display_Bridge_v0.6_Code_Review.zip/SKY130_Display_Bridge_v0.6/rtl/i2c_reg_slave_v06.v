`default_nettype none
// 7-bit address 0x3c, 8-bit register pointer, sequential R/W, repeated START.
// Synchronizes SCL/SDA into clk. Requires sufficiently slow I2C relative to clk
// (at least ~20 clk ticks per SCL period); no clock stretching, filtering,
// multi-master arbitration or timeout. Outputs SDA open-drain low enable.
module i2c_reg_slave_v06(input wire clk,rst_n,scl,sda_in,
 output wire sda_drive_low,input wire [7:0] rd_data,
 output wire [7:0] rd_addr,output reg wr_pulse,
 output reg [7:0] wr_addr,wr_data);
 localparam IDLE=0,RX=1,ACK=2,TX=3,MASTER_ACK=4,TX_TAIL=5;
 reg [2:0] state;
 reg [2:0] scl_ff,sda_ff;
 wire scl_up=(scl_ff[2:1]==2'b01),scl_dn=(scl_ff[2:1]==2'b10);
 wire start=(sda_ff[2:1]==2'b10) && scl_ff[2];
 wire stop=(sda_ff[2:1]==2'b01) && scl_ff[2];
 reg [2:0] bits;
 reg [7:0] rx,tx,ptr;
 reg [1:0] phase; // 0=address;1=register pointer;2=write data
 reg matched,rd,ack_ok,ack_low,ack_high;
 reg [1:0] tx_ack_phase;
 reg master_ack,tx_bit_primed;
 assign rd_addr=ptr;
 assign sda_drive_low=(state==ACK && ack_low && ack_ok) ||
    ((state==TX || state==TX_TAIL) && !tx[7] && tx_bit_primed);
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   scl_ff<=3'b111;sda_ff<=3'b111;state<=IDLE;bits<=0;
   rx<=0;tx<=0;ptr<=0;phase<=0;matched<=0;rd<=0;
   ack_ok<=0;ack_low<=0;ack_high<=0;
   tx_ack_phase<=0;master_ack<=0;tx_bit_primed<=0;
   wr_pulse<=0;wr_addr<=0;wr_data<=0;
  end else begin
   scl_ff<={scl_ff[1:0],scl};sda_ff<={sda_ff[1:0],sda_in};
   wr_pulse<=0;
   if(start) begin
    state<=RX;bits<=0;phase<=0;matched<=0;
    ack_low<=0;ack_high<=0;tx_bit_primed<=0;
   end else if(stop) begin
    state<=IDLE;ack_low<=0;ack_high<=0;tx_bit_primed<=0;
   end else case(state)
    IDLE:begin end
    RX:if(scl_up) begin
     rx<={rx[6:0],sda_ff[2]};
     if(bits==7)begin
      bits<=0;state<=ACK;ack_low<=0;ack_high<=0;
      if(phase==0)begin
       matched<=(rx[6:0]==7'h3c);
       ack_ok<=(rx[6:0]==7'h3c);rd<=sda_ff[2];phase<=1;
      end else if(phase==1)begin
       ack_ok<=matched;
       ptr<={rx[6:0],sda_ff[2]};phase<=2;
      end else begin
       ack_ok<=matched;
       if(matched)begin
        wr_pulse<=1;wr_addr<=ptr;
        wr_data<={rx[6:0],sda_ff[2]};ptr<=ptr+1'b1;
       end
      end
     end else bits<=bits+1'b1;
    end
    ACK:begin
     // ACK only during ninth clock, pull low following byte's eighth falling edge.
     if(scl_dn && !ack_low && !ack_high)ack_low<=1;
     if(scl_up && ack_low)ack_high<=1;
     if(scl_dn && ack_high)begin
      ack_low<=0;ack_high<=0;
      if(!ack_ok)state<=IDLE;
      else if(phase==1 && rd)begin
       state<=TX;bits<=0;tx<=rd_data;tx_bit_primed<=1;
      end else begin state<=RX;bits<=0;end
     end
    end
    TX:begin
     if(scl_up)begin
      if(bits==7)begin
       bits<=0;state<=TX_TAIL;tx_ack_phase<=0;ptr<=ptr+1'b1;
      end else bits<=bits+1'b1;
     end
     if(scl_dn && bits!=0)tx<={tx[6:0],1'b1};
    end
    TX_TAIL:if(scl_dn)begin state<=MASTER_ACK;tx_bit_primed<=0;end
    MASTER_ACK:begin
     if(scl_dn && !tx_ack_phase)tx_ack_phase<=1;
     if(scl_up && tx_ack_phase)begin master_ack<=!sda_ff[2];tx_ack_phase<=2;end
     if(scl_dn && tx_ack_phase==2)begin
      if(master_ack)begin
       tx<=rd_data;bits<=0;tx_bit_primed<=1;state<=TX;
      end else state<=IDLE;
      tx_ack_phase<=0;
     end
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
