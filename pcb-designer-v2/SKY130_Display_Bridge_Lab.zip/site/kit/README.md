# SKY130 Display Bridge v0.6 — Verification Kit

Review companion to original **v0.6**, copied RTL unmodified. No hardware claim.

## Environment

Ubuntu/Debian: `sudo apt update && sudo apt install -y iverilog yosys python3`

From this directory:

```bash
python3 tools/static_review.py
bash scripts/run_verification.sh
bash scripts/report_memory.sh
export SKY130_LIB=/absolute/path/to/sky130_fd_sc_hd__tt_025C_1v80.lib
bash scripts/report_sky130.sh
```

`run_verification.sh` runs the original directed v0.6 top-level and I2C tests **plus** an additional 32-pixel packetizer randomized-backpressure test with an independent Python golden vector. It is not a randomized integrated-SoC test. The pseudo-random sequence is deterministic for repeatability. No simulator or Yosys runs were possible in the packaging environment.

## Gates and expected status

1. **Packetizer stalls**: run `build/random_stalls.log`; must show PASS with byte count 102 and >=5 stalls. Byte-valid must remain stable when ready=0. This **does not** independently establish SoC-level backpressure correctness.
2. **I2C directed read/write**: `build/i2c.log`. Existing test includes one write and repeated START read, but does **not** test wrong-address NACK, multi-byte autoincrement read, reset during transfer, or complete ACK timing. Expand before declaring verified.
3. **DSI packet boundaries**: packetizer test verifies header/body/footer byte values. Existing top-level has short-packet SOP/EOP only. **Gate expected NOT COMPLETE** until long-packet SOP/EOP, sync events, blanking and valid/ready preservation are tested.
4. **RAM**: `build/memory_collect.log` and `build/memory_flops.log`. A `$mem` collection is only RTL memory extraction, **not** SRAM macro inference. Cell-based synthesis may balloon to >=98,304 storage bits + muxing. Obtain a legal SRAM macro and memory compiler mapping/LEF/GDS/lib.
5. **SKY130HD**: `build/sky130_mapped.log`, `build/sky130_summary.txt`; record yosys version, exact Liberty, cell count and area if reported. This is synthesis **not** physical timing closure or signoff.

## Target completion milestones (in order)

- **v0.6.1** repair I2C byte-boundary and full ACK/NACK regressions, malformed-line discard/reset, explicit packet long SOP/EOP, stable protocol during stall.
- **v0.7** real DSI digital transport: HSS/HSE, blanking, DCS initialization, video modes, LP/HS PHY handshake, supported lane/VC mapping; validate with independent scoreboard and target panel specification. Electrical D-PHY remains external.
- **v0.8** dual-clock video elastic buffering with Gray-coded pointers/synchronizers and valid reset domain crossing; SRAM macros and multi-corner STA.
- **v0.9** actual DP link protocol block: AUX, HPD, link training, lane deskew, descrambling/8b10b or supported 128b132b etc, stream recovery. PHY/CDR and board-level signal integrity require external IP.
- **v1.0** firmware CPU/ROM, secure programming/update method, documented boot/recovery, real external LED driver interface with feedback/overcurrent/thermal protection handled by qualified PMIC circuits. NOT a drop-in LT7911UXC or KTZ8866 replacement.

## Source

`rtl/` is copied verbatim from `SKY130_Display_Bridge_v0.6_Code_Review.zip`. `previous_v05/` holds the original predecessor snapshot. New verification files are under `tb/`, `tools/`, `scripts/`. Read `docs/VERIFICATION_MATRIX.md` for complete evidence expectations.
