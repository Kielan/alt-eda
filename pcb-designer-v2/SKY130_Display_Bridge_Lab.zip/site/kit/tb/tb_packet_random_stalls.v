`timescale 1ns/1ps
module tb_packet_random_stalls;
 reg clk=0; always #5 clk=~clk;
 reg rst_n=0,start=0,byte_ready=0;
 reg [23:0] pixel_rgb=0;
 reg pixel_valid=0;
 wire pixel_ready,byte_valid,busy,line_done,underrun;
 wire [7:0] byte_data;
 reg [23:0] pixels[0:31];
 reg [7:0] expected[0:101];
 integer in_idx=0,out_idx=0,cycles=0,stall_count=0;
 reg [31:0] lfsr=32'hCAFE1234;
 reg prev_stalled=0;reg [7:0] prev_data=0;
 dsi_rgb888_packetizer dut(.clk(clk),.rst_n(rst_n),
  .start_line(start),.line_pixels(16'd32),
  .pixel_rgb(pixel_rgb),.pixel_valid(pixel_valid),.pixel_ready(pixel_ready),
  .byte_data(byte_data),.byte_valid(byte_valid),.byte_ready(byte_ready),
  .busy(busy),.line_done(line_done),.underrun_error(underrun));
 initial begin
  $readmemh("build/pixels.hex",pixels);
  $readmemh("build/packet.hex",expected);
  repeat(4) @(negedge clk); rst_n=1;
  @(negedge clk); start=1;
  @(negedge clk); start=0;
  while(!line_done && cycles<30000) begin
    @(negedge clk);
    lfsr={lfsr[30:0],lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};
    byte_ready=(lfsr[2:0]!=0 && lfsr[4:3]!=0);
    pixel_valid=(lfsr[6:5]!=0 && in_idx<32);
    if(in_idx<32)pixel_rgb=pixels[in_idx];
    cycles=cycles+1;
  end
  if(cycles>=30000)$fatal(1,"packetizer timed out");
  if(out_idx!=102)$fatal(1,"got %0d bytes, expected 102",out_idx);
  if(in_idx!=32)$fatal(1,"got %0d pixels, expected 32",in_idx);
  if(stall_count<5)$fatal(1,"insufficient stalls: %0d",stall_count);
  if(underrun)$fatal(1,"unexpected underrun");
  $display("PASS: 32 pixels, 102 exact packet bytes, %0d stalls",stall_count);
  $finish;
 end
 always @(posedge clk) if(rst_n) begin
   if(prev_stalled && (!byte_valid || byte_data!==prev_data))
       $fatal(1,"ready/valid output changed while stalled");
   prev_stalled<=byte_valid && !byte_ready;
   prev_data<=byte_data;
   if(byte_valid && !byte_ready)stall_count=stall_count+1;
   if(byte_valid && byte_ready)begin
     if(out_idx>=102)$fatal(1,"extra byte %h",byte_data);
     if(byte_data!==expected[out_idx])
       $fatal(1,"byte %0d expected %h got %h",out_idx,expected[out_idx],byte_data);
     out_idx=out_idx+1;
   end
   if(pixel_valid && pixel_ready)in_idx=in_idx+1;
 end
endmodule
