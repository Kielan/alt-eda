# v0.6 verification matrix and remediation

| ID | Stimulus | Scoreboard / evidence | Acceptance | As packaged |
|---|---|---|---|---|
| STALL-01 | Deterministic pseudorandom `byte_ready`, 32 RGB pixels | Independent Python DSI bytes, testbench checks stability and sequence | Exact 102-byte match, no drops/duplicates, no timeout | Not executed |
| STALL-02 | Random SoC `dp_valid`, `phy_ready`, 2+ lines | Golden pixel queue, flags aligned | No loss/reorder, bounded completion | Missing; write next |
| STALL-03 | Reset mid-packet | Check partial packet discarded and recovery | Defined reset policy, no deadlock | Missing |
| I2C-01 | Address 0x3c write + repeated START read | Existing bench | ACK and correct read data | Not executed |
| I2C-02 | Wrong-address transaction | ACK-level bus monitor | NACK, no register mutation | Missing |
| I2C-03 | Sequential reads/writes with master ACK/NACK | Reference register model | Pointer increments exactly once per byte | Missing; suspected TX boundary hazard |
| DSI-01 | RGB888 long-packet body | Python reference ECC+CRC | Exact packet bytes | Test provided, not executed |
| DSI-02 | VS_START/VS_END + long packet full boundaries | Independent packet boundary monitor | SOP/EOP asserted on each packet | **Known not satisfied** |
| DSI-03 | HSS/HSE and blanking variants | Panel-mode reference | Conformance to chosen video mode | Not implemented |
| MEM-01 | `memory_collect` before `memory_map` | RTLIL and log | Expected memory inferred | Not executed |
| MEM-02 | SRAM hard macro mapping | Mapping, Liberty/LEF/GDS, STA | No unsupported memory and pass STA | Not implemented |
| SYN-01 | SKY130HD `dfflibmap; abc; stat` | Logged tool/version/Liberty + cells/area | Zero errors, record real values | Not executed |

**Do not** equate a successful Yosys mapping with performance at 2560×1600@144Hz. Throughput needs proper parallelization, physical PHY, clocks, CDC, and STA with panel timing and IO constraints.
