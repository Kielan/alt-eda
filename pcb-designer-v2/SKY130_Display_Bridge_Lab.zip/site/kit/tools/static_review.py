#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'rtl'
ctrl=(p/'dsi_v06_controller.v').read_text()
buf=(p/'line_buffer.v').read_text()
top=(p/'display_soc_v06.v').read_text()
i2c=(p/'i2c_reg_slave_v06.v').read_text()
checks={
 'DSI long-packet SOP/EOP not implemented': 'short_active?short_idx==0:1\'b0' in ctrl and 'short_active?short_idx==3:1\'b0' in ctrl,
 'Malformed line blocks drain without explicit discard': 'line_ready && !err_len' in top and 'discard' not in buf,
 'No two-clock CDC in line buffer': 'input wire clk,rst_n' in buf and 'rd_clk' not in buf,
 'I2C fixed-address slave uses 0x3c': "7'h3c" in i2c,
 'No real physical PHY in top': 'phy_byte' in top and 'dphy' not in top.lower(),
}
for name,found in checks.items(): print(('REVIEW FLAG' if found else 'CHECK MANUALLY')+': '+name)
print('Static review flags are not dynamic test results.')
