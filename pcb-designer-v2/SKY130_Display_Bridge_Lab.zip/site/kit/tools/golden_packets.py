#!/usr/bin/env python3
"""Independent RGB888 DSI header ECC / payload CRC reference, writes byte vectors."""
from pathlib import Path
ECC = [[0,1,2,4,5,7,10,11,13,16,20,21,22,23],
[0,1,3,4,6,8,10,12,14,17,20,21,22,23],
[0,2,3,5,6,9,11,12,15,18,20,21,22],
[1,2,3,7,8,9,13,14,15,19,20,21,23],
[4,5,6,7,8,9,16,17,18,19,20,22,23],
[10,11,12,13,14,15,16,17,18,19,21,22,23]]
def ecc(head):
    bits = sum(v << (8*i) for i,v in enumerate(head))
    return sum((sum((bits >> bit) & 1 for bit in row) & 1) << i for i,row in enumerate(ECC))
def crc16(data):
    crc=0xffff
    for d in data:
        for i in range(8):
            crc=(crc >> 1) ^ (0x8408 if ((crc ^ (d >> i)) & 1) else 0)
    return crc
def packet(pixels):
    body=[chan for rgb in pixels for chan in rgb]
    wc=len(body)
    assert wc<=65535
    h=[0x3e,wc&255,wc>>8]
    crc=crc16(body)
    return h+[ecc(h)]+body+[crc&255,crc>>8]
def main():
    root=Path(__file__).resolve().parents[1]
    out=root/'build';out.mkdir(exist_ok=True)
    pixels=[((i*17+3)&255,(i*29+5)&255,(i*47+7)&255) for i in range(32)]
    (out/'pixels.hex').write_text('\n'.join(f'{r:02x}{g:02x}{b:02x}' for r,g,b in pixels)+'\n')
    pkt=packet(pixels)
    (out/'packet.hex').write_text('\n'.join(f'{x:02x}' for x in pkt)+'\n')
    (out/'packet_summary.txt').write_text(f'pixel_count={len(pixels)}\nword_count={len(pixels)*3}\npacket_bytes={len(pkt)}\nheader={pkt[:4]}\ncrc={pkt[-2:]}\n')
    assert len(pkt)==4+32*3+2
    print('PASS: deterministic independent packet vectors generated')
if __name__=='__main__':main()
