#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
command -v yosys >/dev/null || { echo 'BLOCKED: yosys not installed'; exit 127; }
# Inspect memory IR BEFORE mapping to registers: presence of $mem* is not proof of SRAM macro use.
yosys -Q -T -l build/memory_collect.log -p \
 'read_verilog rtl/line_buffer.v; hierarchy -top line_buffer -chparam DEPTH 4096 -chparam AW 12; proc; opt; memory_dff; memory_collect; stat; write_rtlil build/line_buffer_memory.il'
grep -E '\\$mem|memory|Number of' build/memory_collect.log | tail -25 || true
# Separate generic implementation for resource estimates only.
yosys -Q -T -l build/memory_flops.log -p \
 'read_verilog rtl/line_buffer.v; synth -top line_buffer -flatten; stat'
python3 - <<'PY'
print('Theoretical pixel storage: 4096 * 24 = 98,304 bits (excluding control).')
print('Yosys memory collection is NOT proof of SRAM macro mapping.')
PY
