#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
python3 tools/golden_packets.py
command -v iverilog >/dev/null || { echo 'BLOCKED: iverilog not installed'; exit 127; }
command -v vvp >/dev/null || { echo 'BLOCKED: vvp not installed'; exit 127; }
iverilog -g2012 -Wall -s tb_packet_random_stalls -o build/random.vvp \
  rtl/dsi_ecc_crc.v rtl/dsi_rgb888_packetizer.v tb/tb_packet_random_stalls.v
vvp build/random.vvp | tee build/random_stalls.log
iverilog -g2012 -Wall -s tb_i2c_v06 -o build/i2c.vvp \
  rtl/i2c_reg_slave_v06.v tb/tb_i2c_v06.v
vvp build/i2c.vvp | tee build/i2c.log
iverilog -g2012 -Wall -s tb_v06_soc -o build/soc.vvp \
  rtl/*.v tb/tb_v06_soc.v
vvp build/soc.vvp | tee build/soc.log
