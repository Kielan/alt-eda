#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SKY130_LIB:?Set SKY130_LIB to an existing sky130_fd_sc_hd Liberty file}"
[ -f "$SKY130_LIB" ] || { echo "ERROR: Liberty not found: $SKY130_LIB"; exit 2; }
command -v yosys >/dev/null || { echo 'BLOCKED: yosys not installed'; exit 127; }
mkdir -p build
# Avoid shell interpolation inside the Yosys script except the absolute library path.
yosys -Q -T -l build/sky130_mapped.log -p \
 "read_verilog rtl/*.v; hierarchy -check -top display_soc_v06; synth -top display_soc_v06; dfflibmap -liberty $SKY130_LIB; abc -liberty $SKY130_LIB; clean; check; stat -liberty $SKY130_LIB; write_verilog -noattr build/sky130_mapped.v"
{
 echo 'SKY130HD SYNTHESIS REVIEW (not STA, DRC or tapeout signoff)'
 date -u +'%Y-%m-%dT%H:%M:%SZ'
 yosys -V
 echo "Liberty: $SKY130_LIB"
 grep -A45 '=== display_soc_v06 ===' build/sky130_mapped.log | tail -46 || true
 echo 'Memory observation: mapping used synth, which may expand behavioral arrays to FFs.'
} > build/sky130_summary.txt
cat build/sky130_summary.txt
