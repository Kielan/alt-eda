SKY130 Display Bridge Lab — downloadable site

1. Extract this ZIP.
2. Open site/index.html using a local web server:
   cd site
   python3 -m http.server 8000 --bind 127.0.0.1
   Visit http://127.0.0.1:8000

For a quick offline view, open SKY130_Display_Bridge_Lab_Offline.html.
Keep it beside the site folder so source downloads and release ZIP links work.
The offline page embeds the UI, styles and source viewer; it does not need a server.

Original release ZIPs: site/artifacts/
Extracted verification kit: site/kit/
Run Verilog/Yosys scripts separately in a configured toolchain.
No Verilog or Yosys runs inside this website. Their results remain unverified.

Notes/checklists/logs are saved in the browser. Export workspace JSON from
Progress log on the hosted site, then import it in this copy to transfer your notes.
Moving between a hosted URL and a local file uses separate browser storage.

No physical LT7911UXC_U3/Legion Go compatibility, PHY, firmware CPU or analog
KTZ8866 rail implementation is established.
