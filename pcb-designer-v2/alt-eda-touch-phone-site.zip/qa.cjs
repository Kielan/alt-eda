const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const source=fs.readFileSync('app.js','utf8').split("$('#quickExport').onclick=exportState;")[0];
const c=vm.createContext({structuredClone,document:{querySelector:()=>null},localStorage:{getItem:()=>null},setInterval:()=>{},setTimeout:()=>{},console});
vm.runInContext(source,c);
const run=s=>vm.runInContext(s,c);
run('validate(structuredClone(defaults))');
run("state=structuredClone(defaults); ['AC','2','+','3','='].forEach(calc)");assert.equal(run('state.calc'),'5');
run("['AC','8','÷','0','='].forEach(calc)");assert.equal(run('state.calc'),'Error');
run("calc('AC'); calc('.'); calc('5'); calc('+'); calc('1'); calc('=')");assert.equal(run('state.calc'),'1.5');
run("state=structuredClone(defaults); state.notes='round trip'; state.tests['UI-01']={result:'Pass',note:'5 observed',date:new Date().toISOString()}; state.log.push({date:new Date().toISOString(),text:'QA',kind:'Progress'}); const restored=validate(JSON.parse(JSON.stringify(state)))");assert.equal(run('restored.notes'),'round trip');
for(const mutation of ["s.format='alt-eda.touch-phone'","s.version=2","s.brightness=101","s.mappings[0].status='Verified'","s.selected='imaginary'","s.log=[{kind:'x',date:'invalid',text:'x'}]","s.checks=[99]","s.tests={'unknown':{result:'Pass',note:'x',date:new Date().toISOString()}}"]){assert.throws(()=>run(`{const s=structuredClone(defaults);${mutation};validate(s)}`))}
console.log('PASS: calculator arithmetic, zero division, decimal flow, snapshot round trip and eight invalid-state guards.');
