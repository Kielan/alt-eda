alt-EDA Touch Phone Lab — downloadable Site

Quick start
1. Extract this ZIP completely.
2. Open index.html in a modern desktop browser.
3. If local-file storage is restricted, serve this folder with:
   python3 -m http.server 8000
   Then open http://localhost:8000

Included
- index.html, style.css, app.js: current validation workspace
- baseline.html: original Touch Phone v0.1 prototype
- baseline-notes.md: original baseline notes
- qa.cjs: optional Node.js checks (run node qa.cjs from this folder)

The workspace itself has no required external JavaScript dependencies.
Google Fonts uses an internet connection, with system-font fallbacks.
The original baseline's 3D assembly requires accessible Three.js CDN imports
and WebGL. Its screen preview is independent of the 3D renderer.

Data and evidence
This download contains the Site code, not entries saved in your browser.
To transfer existing notes and results, use Export snapshot on the hosted
Site, then Import workspace in this local copy. Browser-local data does not
automatically transfer between URLs, browsers or devices.

Assembly dimensions are assumptions. Screen behavior is browser simulation.
No routed copper, verified GPIO mapping, cellular radio, iOS, or ESP32 firmware
emulation is implemented by this download. Hardware evidence starts empty.

Source commit: 12d3eba8357f46e3b3043b0f93100fd77cb1f678
