# Touch Phone 0.1 — New project

## Video observations

The supplied clip is approximately 14.8 seconds long. Sampled frames show:

- Around 0 seconds: a blue controller board held in portrait orientation.
- Around 3 seconds: a web prompt asking for a phone-style interface.
- Around 6–9 seconds: the label `ESP32-P4-WIFI6-TOUCH-LCD-4.3` and a powered portrait touchscreen with an app grid, a blue case edge, and a cable plugged into its bottom.
- Around 12 seconds: an interactive calculator on the touchscreen.

The clip does not establish internal pin assignments, dimensions, battery operation, cellular service, iOS execution, or a verified schematic. The board label is reproduced as a video observation, not an independently verified specification. The display is described as an LCD/touch proxy, not a confirmed OLED.

## Included prototype

Open `alt-eda-phone-v01.html` in a browser. It is a separate project, not a modification of the v13 casing candidate. The right-hand phone preview runs without external libraries. Its Calculator, Notes, Clock, and Settings respond to interaction; Calls and Camera explicitly show unavailable states. Notes persist while this page remains open, not after a reload. Clock app shows the opening time; status-bar time updates live.

The center shows a Three.js assembly when CDN imports and WebGL are available: rear case, controller PCB, conceptual processor package, illustrative shield, USB-C proxy, display, and touch/cover face. Select a part to highlight it, orbit, inspect from the rear, or explode along the device thickness axis. The enclosure is a simple box proxy, not a hollow manufacturable case. Assumed outer dimensions are 76 × 142 × 15 mm.

Export project saves a versioned `alt-eda.touch-phone` JSON document; Import project restores its part geometry. This format belongs to this new demo, not the older alt-EDA importers. UI runtime state is not serialized. The model has no battery because battery operation is not established by the reference. Conceptual two-layer PCB metadata is distinct from assembly geometry, with no routed traces or vias.

## Next small implementation milestone

Replace box casing proxies with the dimensioned tray/face workflow from v13, then add a selectable PCB/touch connector with explicit logical endpoints. Confirm the exact board revision before introducing real connector pin mappings or manufacturing dimensions.
