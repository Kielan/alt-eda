
import * as THREE from "three"
import { Footprint } from "./Footprint"

export class Component {

  footprint: Footprint
  position: THREE.Vector3
  rotation: number = 0
  group = new THREE.Group()

  constructor(fp: Footprint, position: THREE.Vector3) {
    this.footprint = fp
    this.position = position
    this.build()
  }

  build() {
    this.group.clear()

    for (const pad of this.footprint.pads) {

      const geo = new THREE.CircleGeometry(pad.size, 16)
      const mat = new THREE.MeshStandardMaterial({ color: 0xffcc00 })

      const mesh = new THREE.Mesh(geo, mat)
      mesh.rotation.x = -Math.PI / 2

      mesh.position.copy(pad.position)

      this.group.add(mesh)
    }

    this.group.position.copy(this.position)
  }
}
