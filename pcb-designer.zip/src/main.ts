
import * as THREE from "three"
import { Footprint } from "./cad/Footprint"
import { Component } from "./cad/Component"

const scene = new THREE.Scene()
scene.background = new THREE.Color(0x000000)

const camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 1000)
camera.position.set(0, 100, 100)

const renderer = new THREE.WebGLRenderer()
renderer.setSize(window.innerWidth, window.innerHeight)
document.body.appendChild(renderer.domElement)

const light = new THREE.HemisphereLight(0xffffff, 0x444444, 1)
scene.add(light)

// Example footprint
const resistor = new Footprint("R_0603", [
  { position: new THREE.Vector3(-2,0,0), size: 1 },
  { position: new THREE.Vector3(2,0,0), size: 1 }
])

const comp = new Component(resistor, new THREE.Vector3(0,0,0))
scene.add(comp.group)

function animate(){
  requestAnimationFrame(animate)
  renderer.render(scene, camera)
}

animate()
